const express = require('express');
const multer = require('multer');
const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');
const { getSessionCookies, loginToTurnitin } = require('../sessionManager');

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

router.post('/upload-document', upload.single('file'), async (req, res) => {
  const { assignment_id, author_id, submission_title, submission_filename, object_id } = req.body;
  const file = req.file;

  if (!file) {
    return res.status(400).json({ message: 'File tidak ada' });
  }

  const form = new FormData();
  form.append('submission_title', submission_title);
  form.append('multi_file_token', '');
  form.append('fileupload', fs.createReadStream(file.path));
  form.append('submission_filename', submission_filename);
  form.append('object_id', object_id || '');

  async function tryUpload() {
    const { legacySessionId, sessionId } = await getSessionCookies();

    try {
      const uploadResponse = await axios.post(
        `https://www.turnitin.com/api/lti/1p0/redirect/upload_submission/${assignment_id}/${author_id}`,
        form,
        {
          headers: {
            ...form.getHeaders(),
            Cookie: `legacy-session-id=${legacySessionId}; session-id=${sessionId}`
          }
        }
      );

      return uploadResponse.data;
    } catch (error) {
      if (error.response && error.response.status === 401) {
        console.log('⚠️ Session expired, login ulang...');
        await loginToTurnitin(); // login lagi
        return await tryUpload(); // retry sekali lagi
      } else {
        throw error;
      }
    }
  }

  try {
    const result = await tryUpload();
    res.json({ message: '✅ Upload sukses', data: result });
  } catch (error) {
    console.error('❌ Upload gagal:', error.message);
    res.status(500).json({ message: 'Gagal upload dokumen', error: error.message });
  } finally {
    // Bersihkan file upload lokal
    fs.unlinkSync(file.path);
  }
});

module.exports = router;
