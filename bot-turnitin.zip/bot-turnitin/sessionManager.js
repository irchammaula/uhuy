const axios = require('axios');

// Memory store session
let sessionCookies = {
  legacySessionId: null,
  sessionId: null
};

// Login function manual (tanpa Puppeteer)
async function loginToTurnitin() {
  try {
    const response = await axios.post('https://www.turnitin.com/login_page.asp', {
      email: process.env.TURNITIN_EMAIL,
      user_password: process.env.TURNITIN_PASSWORD
    }, {
      maxRedirects: 0,
      validateStatus: (status) => status === 302 // redirect success
    });

    const setCookie = response.headers['set-cookie'];
    if (!setCookie) throw new Error('Login gagal: tidak ada cookie');

    // Ambil legacy-session-id dan session-id
    const legacySession = /legacy-session-id=([^;]+);/.exec(setCookie.join(';'));
    const session = /session-id=([^;]+);/.exec(setCookie.join(';'));

    if (!legacySession || !session) {
      throw new Error('Login gagal: session id tidak ditemukan');
    }

    sessionCookies.legacySessionId = legacySession[1];
    sessionCookies.sessionId = session[1];

    console.log('✅ Session updated:', sessionCookies);
  } catch (error) {
    console.error('❌ Gagal login:', error.message);
    throw error;
  }
}

// Get cookies, login dulu kalau belum ada
async function getSessionCookies() {
  if (!sessionCookies.legacySessionId || !sessionCookies.sessionId) {
    console.log('⚠️ Session kosong, login ulang...');
    await loginToTurnitin();
  }
  return sessionCookies;
}

module.exports = { getSessionCookies, loginToTurnitin };
