const express = require('express');
const puppeteer = require('puppeteer');
const fs = require('fs');
const axios = require('axios');
const FormData = require('form-data');
const path = require('path');
const multer = require('multer');

const app = express();
const port = 3000;

const TEMP_DIR = path.join(__dirname, 'temp');
if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, { recursive: true });
}

const upload = multer({ dest: TEMP_DIR });
const COOKIE_FILE = path.join(__dirname, 'cookies.json');

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// === Endpoint Login Turnitin ===
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email dan password diperlukan' });
  }

  try {
    const browser = await puppeteer.launch({ headless: true });
    const page = await browser.newPage();

    await page.goto('https://www.turnitin.com/login_page.asp', { waitUntil: 'networkidle2' });

    await page.type('input[name="email"]', email, { delay: 50 });
    await page.type('input[name="user_password"]', password, { delay: 50 });

    await Promise.all([
      page.waitForNavigation({ waitUntil: 'networkidle2' }),
      page.click('input[type="submit"]'),
    ]);

    const cookies = await page.cookies();
    const legacySession = cookies.find(c => c.name === 'legacy-session-id');
    const sessionId = cookies.find(c => c.name === 'session-id');

    await browser.close();

    if (!legacySession || !sessionId) {
      return res.status(401).json({ message: 'Login gagal. Pastikan kredensial benar atau CAPTCHA tidak memblokir.' });
    }

    fs.writeFileSync(COOKIE_FILE, JSON.stringify(cookies, null, 2));

    res.json({
      message: 'Login berhasil!',
      legacySessionId: legacySession.value,
      sessionId: sessionId.value,
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Terjadi kesalahan saat login', error: error.message });
  }
});

// === Endpoint Upload Dokumen ===
app.post('/upload', upload.single('fileupload'), async (req, res) => {
  try {
    const cookies = JSON.parse(fs.readFileSync(COOKIE_FILE, 'utf8'));
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    const { assignmentId, authorId, submissionTitle } = req.body;
    const filePath = req.file?.path;

    if (!assignmentId || !authorId || !submissionTitle || !filePath) {
      return res.status(400).json({ message: 'assignmentId, authorId, submissionTitle, dan file wajib diisi' });
    }

    const form = new FormData();
    form.append('submission_title', submissionTitle);
    form.append('multi_file_token', '');
    form.append('fileupload', fs.createReadStream(filePath));
    form.append('submission_filename', path.basename(filePath));
    form.append('object_id', '');

    const response = await axios.post(
      `https://www.turnitin.com/api/lti/1p0/redirect/upload_submission/${assignmentId}/${authorId}`,
      form,
      {
        headers: {
          ...form.getHeaders(),
          Cookie: cookieHeader,
        },
        maxBodyLength: Infinity,
      }
    );

    res.json({ message: 'Upload berhasil', data: response.data });
  } catch (error) {
    console.error(error);
    res.status(error.response?.status || 500).json({
      message: 'Gagal upload dokumen',
      error: error.message,
      response: error.response?.data || null,
    });
  }
});

// === Endpoint Submit Dokumen ===
app.get('/submit', async (req, res) => {
  const { idFile, assignmentId, authorId } = req.query;

  if (!idFile || !assignmentId || !authorId) {
    return res.status(400).json({ message: 'idFile, assignmentId, dan authorId wajib diisi' });
  }

  try {
    const cookies = JSON.parse(fs.readFileSync(COOKIE_FILE, 'utf8'));
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    const url = `https://www.turnitin.com/api/lti/1p0/redirect/upload_save_request/${idFile}/${assignmentId}?lang=en_us&author_id=${authorId}&placeholder=0`;

    const response = await axios.get(url, {
      headers: {
        Cookie: cookieHeader,
      }
    });

    res.json({ message: 'Submit berhasil', data: response.data });
  } catch (error) {
    console.error('Submit error:', error.response?.data || error.message);
    res.status(error.response?.status || 500).json({
      message: 'Gagal submit dokumen',
      error: error.message,
      response: error.response?.data || null,
    });
  }
});

// === Endpoint Generate Feedback URL ===
app.get('/feedback', (req, res) => {
  const { objectId, author_id, feedbackType = '103' } = req.query;

  if (!objectId || !author_id) {
    return res.status(400).json({ message: 'objectId dan author_id wajib diisi' });
  }

  const feedbackUrl = `https://ev.turnitin.com/app/carta/en_us/?o=${objectId}&u=${author_id}&lang=en_int&ro=${feedbackType}&student_user=1`;

  res.json({
    message: 'Berhasil generate feedback URL',
    feedbackUrl,
  });
});

// Jalankan server
app.listen(port, () => {
  console.log(`Server berjalan di http://localhost:${port}`);
});
